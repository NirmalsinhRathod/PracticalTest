import { StyleSheet } from 'react-native';
export default styles = StyleSheet.create({
    extraPadding: {
        paddingLeft: 10,
        paddingRight: 10
    }
});
