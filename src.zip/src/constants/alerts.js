
export const SIGNUP_SUCCESS = 'You are successfull registered. Kindy confirm your email address to approve your account.'
export const LOGOUT = 'Are you sure you want to logout?'