export const LOADER_BG = 'rgba(0, 0, 0, 0.8)';
export const INDICATOR = 'white';
export const MAIN_BG_COLOR = 'rgba(33, 150, 243, 0.6)';


//Tab selected and Normal Color
export const TAB_SELECTED = '#2196f3';
export const TAB_NORMAL = 'black';
